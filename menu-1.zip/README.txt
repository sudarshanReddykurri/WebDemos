A Pen created at CodePen.io. You can find this one at http://codepen.io/SudarshanReddy/pen/ByPLxb.

 

Forked from [Virgil Pana](http://codepen.io/virgilpana/)'s Pen [Menu 1](http://codepen.io/virgilpana/pen/NPzodr/).

Forked from [Virgil Pana](http://codepen.io/virgilpana/)'s Pen [Menu 1](http://codepen.io/virgilpana/pen/NPzodr/).