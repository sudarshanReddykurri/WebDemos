A Pen created at CodePen.io. You can find this one at http://codepen.io/SudarshanReddy/pen/jEvLaJ.

 Animated 3d box/cube written in html/css. Based it on a tutorial from David Walsh. http://davidwalsh.name/css-cube

Forked from [Cliff Pyles](http://codepen.io/cliffpyles/)'s Pen [3d box](http://codepen.io/cliffpyles/pen/LHlqa/).