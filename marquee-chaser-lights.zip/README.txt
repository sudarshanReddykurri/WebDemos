A Pen created at CodePen.io. You can find this one at http://codepen.io/SudarshanReddy/pen/QwVZgb.

 Just for fun!

Treehouse livestreamed the creation of this pen. Go here to watch the recording: http://www.youtube.com/watch?v=igTXtG8Wvl4

Forked from [Nick Pettit](http://codepen.io/nickpettit/)'s Pen [Marquee Chaser Lights](http://codepen.io/nickpettit/pen/IsqBG/).