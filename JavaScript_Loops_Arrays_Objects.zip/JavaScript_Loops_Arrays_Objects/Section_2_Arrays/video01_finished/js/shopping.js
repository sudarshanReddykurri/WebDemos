var shoppingList = [ 
  'carrots',
  'milk',
  'eggs'
];