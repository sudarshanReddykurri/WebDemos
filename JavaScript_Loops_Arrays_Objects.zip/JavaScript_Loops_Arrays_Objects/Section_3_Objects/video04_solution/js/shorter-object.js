var questions = [
  { question: 'How many states are in the United States?', answer: 50 },
  { question: 'How many continents are there?', answer: 7 },
  { question: 'How many legs does an insect have?', answer: 6 }
];